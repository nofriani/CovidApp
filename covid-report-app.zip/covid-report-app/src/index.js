import 'regenerator-runtime';
import './style/style.css';
import main from './scripts/main.js';

main();