import illustration from '../../logo.png';

class HeaderContent extends HTMLElement{
    connectedCallback(){
        this.render();
    }

    render(){
        this.innerHTML = `<div class="container mt-5 mt-md-2">
                            <div class="row align-items-center">
                                <div class="col-12 col-lg-8 text-xs-center text-center text-lg-left">
                                    <div class="header-caption px-4 py-1">
                                        100+ negara telah terinfeksi
                                    </div>
                                    <h1 class="text-white header-text pt-2">WASPADA <span class="text-orange">COVID-19</span></h1>
                                    <p class="header-subtext text-gray mt-3 mb-5 text-justify">
                                        Penyakit ini disebabkan oleh virus korona jenis baru yang diberi nama SARS-CoV-2. Wabah Covid-19 pertama kali dideteksi di Kota Wuhan, Hubei, Tiongkok pada tanggal 31 Desember 2019, dan ditetapkan sebagai pandemi oleh Organisasi Kesehatan Dunia (WHO) pada tanggal 11 Maret 2020.
                                    </p>
                                    <a href="https://covid19.go.id/edukasi/pengantar" target="_blank" class="mt-2 text-decoration-none btn-corona-detail d-inline-block">
                                        <h2 class="text-orange">Apa Itu Covid-19 ?</h2>
                                    </a>
                                </div>
                                <div class="col-12 col-lg-4 position-relative illustration text-center">
                                    <img src="${illustration}" class="img-illustration">
                                </div>
                            </div>
                        </div>`;
    }
}

customElements.define('header-content',HeaderContent);