class HeaderFooter extends HTMLElement{
    connectedCallback(){
        this.render();
    }

    render(){
        this.innerHTML = `<div class="container text-center mt-4">
                            <marquee><p class="footer">Vaksin Booster dan Jangan Lupa Selalu Pakai Masker.</p></marquee>
                        </div>`;
    }
}

customElements.define('header-footer',HeaderFooter);